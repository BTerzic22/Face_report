# Face report

## Extract and compile patients' reviews on sleep apnea masks for R&D



**Warnings**:



**PS:** The program is still under development. I intend to make it more efficient, cleaner and add a sharing feature.